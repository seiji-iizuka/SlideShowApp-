//
//  ViewController.swift
//  SlideViewApp0601
//
//  Created by seiji iizuka on 2021/06/01.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var imageView: UIImageView!
    
    @IBOutlet weak var startButton: UIButton!
    @IBOutlet weak var nextButton: UIButton!
    @IBOutlet weak var backButton: UIButton!
    
    var nowIndex:Int = 0
    var timer: Timer!
    var timer_sec: Float = 0
    
    let image = [UIImage(named: "1Alfa.jpg"), UIImage(named: "2Hymer.jpg"), UIImage(named: "3Porsche.jpg"), UIImage(named: "4Corvette.jpg"), UIImage(named: "5Mercedes.jpg")]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
    }
    override func didReceiveMemoryWarning(){
        super.didReceiveMemoryWarning()
    }
    
    @IBAction func startButton(_ sender: Any) {
        if (timer == nil) {
            
            timer = Timer.scheduledTimer(timeInterval: 2.0, target: self, selector: #selector(changeImage), userInfo: nil, repeats: true)
            startButton.setTitle("停止", for: .normal)
            backButton.isEnabled = false
            nextButton.isEnabled = false
            
        } else {
            
            timer.invalidate()
            timer = nil
            startButton.setTitle("再生", for: .normal)
            backButton.isEnabled = true
            nextButton.isEnabled = true
            
        }
        
    }
    
    @objc func changeImage() {
        nowIndex += 1
        
        if (nowIndex == image.count) {
            nowIndex = 0
        }
        imageView.image = image[nowIndex]
    }
    
    @IBAction func nextButton(_ sender: Any) {
        nowIndex = nowIndex + 1
        if ( nowIndex > 4 ) {
            nowIndex = 0
        }
        imageView.image = image[nowIndex]
    }
    
    @IBAction func backButton(_ sender: Any) {
        if nowIndex == 0 {
            nowIndex = 4
            
        } else {
            nowIndex -= 1
        }
        imageView.image = image[nowIndex]
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?){
        let photoUpViewController: PhotoUpViewController = segue.destination as! PhotoUpViewController
        photoUpViewController.image = self.image[nowIndex]
    }
    
    @IBAction func tapAction(_ sender: Any) {
        if self.timer != nil{
            timer.invalidate()
            self.timer = nil
            startButton.setTitle("再生", for: .normal)
            nextButton.isEnabled = true
            backButton.isEnabled = true
        }
        performSegue(withIdentifier: "tapImage", sender: nil)
    }
    
    @IBAction func unwind(_ segue: UIStoryboardSegue) {
        
    }
}
